#!/bin/sh
docker-compose up --build